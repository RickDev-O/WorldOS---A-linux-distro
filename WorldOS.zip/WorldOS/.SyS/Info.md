_ROOT info_

* This paste is the sys root okay.