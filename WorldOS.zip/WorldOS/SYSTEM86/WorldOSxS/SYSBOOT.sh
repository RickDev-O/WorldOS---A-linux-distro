clear
echo "Welcome to WorldOS."
echo "Ver 1.0.0, Build 1" 
bash ./WorldOS/.SyS/Autoexec.sh
while :; do
 read -p "$ " cmd
 $cmd
done