_WorldOSxS Info_

* This WorldOSxS is a paste for boot in linux for not bug.
