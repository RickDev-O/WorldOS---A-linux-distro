_SYSTEM86 Info_

* This paste is the paste of the boot.