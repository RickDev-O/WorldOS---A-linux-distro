_Welcome to OS!_

* Welcome to OS! 

_Updates Info:_

* Ver 2.0 Build 1 "City's"

_How to download the system?_
* You need a: _-$ git clone https://github.com/RickDev-O/WorldOS---A-linux-distro_