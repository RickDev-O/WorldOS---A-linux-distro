echo put this cmd: cd ./WorldOS/ROOT/users/Dev,User
#Put the cmd here:
























exit