clear
echo "Welcome to WorldOS."
echo "Build 0002" 
echo "By DevSystems, site: https://devsystems.ricardojunior6.repl.co/ "
bash ./WorldOS/ROOT/Autoexec.sh