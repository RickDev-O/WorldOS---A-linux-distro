clear
echo "Welcome to WorldOS."
echo "Build 0002" 
echo "By DevSystems, site: https://devsystems.ricardojunior6.repl.co/ " 
cd ./WorldOS/ROOT/users/Dev,User
while :; do
 read -p "$ " cmd
 $cmd
done