_Welcome to OS!_

* Welcome to OS! 

_Updates Info:_

* Build 0002 

_How to download the system?_
* You need a: _-$ git clone https://github.com/RickDev-O/WorldOS---A-linux-distro_